MOHIBUL FF CRAFTLAND Android App
Android Studio দিয়ে project open করো → Gradle Sync → Build > Build APK(s)।
APK: app/build/outputs/apk/debug/app-debug.apk
